import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { CheckCircle, Mail, Shield } from "lucide-react"

export default function Page() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-green-600 p-3 rounded-full">
              <CheckCircle className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Account Created!</h1>
        </div>

        <Card className="shadow-xl border-0">
          <CardHeader className="text-center space-y-1 pb-6">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Mail className="h-5 w-5 text-blue-600" />
              <CardTitle className="text-2xl font-semibold text-slate-900">Check Your Email</CardTitle>
            </div>
            <CardDescription className="text-slate-600">We've sent you a verification link</CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-slate-700">
                You've successfully created your SecureBank account. Please check your email and click the verification
                link to activate your account and access your banking dashboard.
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm text-slate-600">
                <Shield className="h-4 w-4 text-green-600" />
                <span>Account security verification required</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-slate-600">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span>Default savings account will be created</span>
              </div>
            </div>

            <div className="pt-4">
              <Link href="/auth/login">
                <Button className="w-full h-11 bg-blue-600 hover:bg-blue-700 text-white font-medium">
                  Return to Login
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 text-center">
          <p className="text-xs text-slate-500">Didn't receive the email? Check your spam folder or contact support.</p>
        </div>
      </div>
    </div>
  )
}
