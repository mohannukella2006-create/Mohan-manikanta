import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { AlertTriangle, Shield } from "lucide-react"

export default async function Page({ searchParams }: { searchParams: Promise<{ error: string }> }) {
  const params = await searchParams

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-red-600 p-3 rounded-full">
              <AlertTriangle className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Access Error</h1>
        </div>

        <Card className="shadow-xl border-0">
          <CardHeader className="text-center space-y-1 pb-6">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Shield className="h-5 w-5 text-red-600" />
              <CardTitle className="text-2xl font-semibold text-slate-900">Authentication Failed</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              {params?.error ? (
                <p className="text-sm text-red-700">
                  <strong>Error:</strong> {params.error}
                </p>
              ) : (
                <p className="text-sm text-red-700">An authentication error occurred. Please try again.</p>
              )}
            </div>

            <div className="space-y-3">
              <Link href="/auth/login">
                <Button className="w-full h-11 bg-blue-600 hover:bg-blue-700 text-white font-medium">
                  Return to Login
                </Button>
              </Link>
              <Link href="/auth/sign-up">
                <Button
                  variant="outline"
                  className="w-full h-11 border-slate-300 text-slate-700 hover:bg-slate-50 bg-transparent"
                >
                  Create New Account
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 text-center">
          <p className="text-xs text-slate-500">Need help? Contact our support team for assistance.</p>
        </div>
      </div>
    </div>
  )
}
