import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Get authenticated user
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { fromAccountId, toAccountNumber, amount, description } = await request.json()

    if (!fromAccountId || !toAccountNumber || !amount || amount <= 0) {
      return NextResponse.json({ error: "Invalid request data" }, { status: 400 })
    }

    // Verify sender account belongs to user
    const { data: fromAccount, error: fromAccountError } = await supabase
      .from("accounts")
      .select("*")
      .eq("id", fromAccountId)
      .eq("user_id", user.id)
      .single()

    if (fromAccountError || !fromAccount) {
      return NextResponse.json({ error: "Sender account not found" }, { status: 404 })
    }

    // Check if recipient account exists
    const { data: toAccount, error: toAccountError } = await supabase
      .from("accounts")
      .select("*")
      .eq("account_number", toAccountNumber)
      .single()

    if (toAccountError || !toAccount) {
      return NextResponse.json({ error: "Recipient account not found" }, { status: 404 })
    }

    // Check sufficient funds
    if (Number(fromAccount.balance) < Number(amount)) {
      return NextResponse.json({ error: "Insufficient funds" }, { status: 400 })
    }

    // Calculate new balances
    const newFromBalance = Number(fromAccount.balance) - Number(amount)
    const newToBalance = Number(toAccount.balance) + Number(amount)

    const referenceNumber = `TXN${Date.now()}${Math.floor(Math.random() * 1000)}`

    // Create outgoing transaction
    const { data: outTransaction, error: outTransactionError } = await supabase
      .from("transactions")
      .insert({
        account_id: fromAccountId,
        transaction_type: "transfer_out",
        amount: Number(amount),
        balance_after: newFromBalance,
        description: description || "Money transfer",
        reference_number: referenceNumber,
        recipient_account_number: toAccountNumber,
      })
      .select()
      .single()

    if (outTransactionError) {
      return NextResponse.json({ error: "Failed to create outgoing transaction" }, { status: 500 })
    }

    // Create incoming transaction
    const { data: inTransaction, error: inTransactionError } = await supabase
      .from("transactions")
      .insert({
        account_id: toAccount.id,
        transaction_type: "transfer_in",
        amount: Number(amount),
        balance_after: newToBalance,
        description: `Transfer from ****${fromAccount.account_number.slice(-4)}`,
        reference_number: referenceNumber,
        recipient_account_number: fromAccount.account_number,
      })
      .select()
      .single()

    if (inTransactionError) {
      // Rollback outgoing transaction
      await supabase.from("transactions").delete().eq("id", outTransaction.id)
      return NextResponse.json({ error: "Failed to create incoming transaction" }, { status: 500 })
    }

    // Update sender account balance
    const { error: updateFromError } = await supabase
      .from("accounts")
      .update({
        balance: newFromBalance,
        updated_at: new Date().toISOString(),
      })
      .eq("id", fromAccountId)

    if (updateFromError) {
      // Rollback transactions
      await supabase.from("transactions").delete().eq("id", outTransaction.id)
      await supabase.from("transactions").delete().eq("id", inTransaction.id)
      return NextResponse.json({ error: "Failed to update sender balance" }, { status: 500 })
    }

    // Update recipient account balance
    const { error: updateToError } = await supabase
      .from("accounts")
      .update({
        balance: newToBalance,
        updated_at: new Date().toISOString(),
      })
      .eq("id", toAccount.id)

    if (updateToError) {
      // Rollback everything
      await supabase.from("transactions").delete().eq("id", outTransaction.id)
      await supabase.from("transactions").delete().eq("id", inTransaction.id)
      await supabase.from("accounts").update({ balance: fromAccount.balance }).eq("id", fromAccountId)
      return NextResponse.json({ error: "Failed to update recipient balance" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      outTransaction,
      inTransaction,
      newFromBalance,
      newToBalance,
    })
  } catch (error) {
    console.error("Transfer error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
