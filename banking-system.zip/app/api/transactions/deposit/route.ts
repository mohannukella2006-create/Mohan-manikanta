import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Get authenticated user
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { accountId, amount, description } = await request.json()

    if (!accountId || !amount || amount <= 0) {
      return NextResponse.json({ error: "Invalid request data" }, { status: 400 })
    }

    // Verify account belongs to user
    const { data: account, error: accountError } = await supabase
      .from("accounts")
      .select("*")
      .eq("id", accountId)
      .eq("user_id", user.id)
      .single()

    if (accountError || !account) {
      return NextResponse.json({ error: "Account not found" }, { status: 404 })
    }

    // Calculate new balance
    const newBalance = Number(account.balance) + Number(amount)

    // Start transaction
    const { data: transaction, error: transactionError } = await supabase
      .from("transactions")
      .insert({
        account_id: accountId,
        transaction_type: "deposit",
        amount: Number(amount),
        balance_after: newBalance,
        description: description || "Cash deposit",
        reference_number: `TXN${Date.now()}${Math.floor(Math.random() * 1000)}`,
      })
      .select()
      .single()

    if (transactionError) {
      return NextResponse.json({ error: "Failed to create transaction" }, { status: 500 })
    }

    // Update account balance
    const { error: updateError } = await supabase
      .from("accounts")
      .update({
        balance: newBalance,
        updated_at: new Date().toISOString(),
      })
      .eq("id", accountId)

    if (updateError) {
      // Rollback transaction if balance update fails
      await supabase.from("transactions").delete().eq("id", transaction.id)
      return NextResponse.json({ error: "Failed to update balance" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      transaction,
      newBalance,
    })
  } catch (error) {
    console.error("Deposit error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
