import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Get authenticated user
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { accountId, dateFrom, dateTo, transactionType } = await request.json()

    // Get user profile
    const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

    // Get user accounts
    const { data: accounts } = await supabase.from("accounts").select("*").eq("user_id", user.id)

    if (!accounts || accounts.length === 0) {
      return NextResponse.json({ error: "No accounts found" }, { status: 404 })
    }

    // Build query for transactions
    let query = supabase
      .from("transactions")
      .select("*")
      .in(
        "account_id",
        accounts.map((acc) => acc.id),
      )
      .order("created_at", { ascending: false })

    // Apply filters
    if (accountId && accountId !== "all") {
      query = query.eq("account_id", accountId)
    }

    if (dateFrom) {
      query = query.gte("created_at", new Date(dateFrom).toISOString())
    }

    if (dateTo) {
      const endDate = new Date(dateTo)
      endDate.setHours(23, 59, 59, 999)
      query = query.lte("created_at", endDate.toISOString())
    }

    if (transactionType && transactionType !== "all") {
      query = query.eq("transaction_type", transactionType)
    }

    const { data: transactions } = await query

    // Generate PDF content (simplified HTML that can be converted to PDF)
    const htmlContent = generateStatementHTML({
      profile: profile || { full_name: "User" },
      accounts,
      transactions: transactions || [],
      filters: { accountId, dateFrom, dateTo, transactionType },
    })

    // In a real application, you would use a PDF generation library like Puppeteer or jsPDF
    // For this example, we'll return the HTML content as a simple text file
    const response = new NextResponse(htmlContent, {
      headers: {
        "Content-Type": "text/html",
        "Content-Disposition": `attachment; filename="statement-${new Date().toISOString().split("T")[0]}.html"`,
      },
    })

    return response
  } catch (error) {
    console.error("Statement download error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

function generateStatementHTML({
  profile,
  accounts,
  transactions,
  filters,
}: {
  profile: any
  accounts: any[]
  transactions: any[]
  filters: any
}) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const formatAccountNumber = (accountNumber: string) => {
    return `${accountNumber.slice(0, 4)} ${accountNumber.slice(4, 8)} ${accountNumber.slice(8)}`
  }

  const getAmountPrefix = (type: string) => {
    switch (type) {
      case "deposit":
      case "transfer_in":
        return "+"
      case "withdraw":
      case "transfer_out":
        return "-"
      default:
        return ""
    }
  }

  const selectedAccount = accounts.find((acc) => acc.id === filters.accountId)

  return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Account Statement - SecureBank</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #2563eb;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .bank-name {
            font-size: 28px;
            font-weight: bold;
            color: #2563eb;
            margin-bottom: 5px;
        }
        .statement-title {
            font-size: 18px;
            color: #64748b;
        }
        .customer-info {
            margin-bottom: 30px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
        }
        .account-summary {
            background-color: #f8fafc;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        .summary-item {
            text-align: center;
        }
        .summary-label {
            font-size: 12px;
            color: #64748b;
            margin-bottom: 5px;
        }
        .summary-value {
            font-size: 16px;
            font-weight: bold;
            color: #1e293b;
        }
        .transactions-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .transactions-table th,
        .transactions-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        .transactions-table th {
            background-color: #f1f5f9;
            font-weight: bold;
            color: #475569;
        }
        .amount-positive {
            color: #059669;
        }
        .amount-negative {
            color: #dc2626;
        }
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
            text-align: center;
            font-size: 12px;
            color: #64748b;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="bank-name">SecureBank</div>
        <div class="statement-title">Account Statement</div>
    </div>

    <div class="customer-info">
        <h3>Customer Information</h3>
        <div class="info-row">
            <span><strong>Name:</strong> ${profile.full_name}</span>
            <span><strong>Statement Date:</strong> ${new Date().toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
              day: "numeric",
            })}</span>
        </div>
        ${
          profile.phone_number
            ? `<div class="info-row">
            <span><strong>Phone:</strong> ${profile.phone_number}</span>
            <span></span>
        </div>`
            : ""
        }
        ${
          filters.dateFrom || filters.dateTo
            ? `<div class="info-row">
            <span><strong>Period:</strong> ${filters.dateFrom || "Beginning"} to ${filters.dateTo || "Present"}</span>
            <span></span>
        </div>`
            : ""
        }
    </div>

    ${
      selectedAccount
        ? `
    <div class="account-summary">
        <h3>Account Summary</h3>
        <div class="summary-grid">
            <div class="summary-item">
                <div class="summary-label">Account Number</div>
                <div class="summary-value">${formatAccountNumber(selectedAccount.account_number)}</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Account Type</div>
                <div class="summary-value">${selectedAccount.account_type.charAt(0).toUpperCase() + selectedAccount.account_type.slice(1)}</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Current Balance</div>
                <div class="summary-value">${formatCurrency(Number(selectedAccount.balance))}</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Total Transactions</div>
                <div class="summary-value">${transactions.length}</div>
            </div>
        </div>
    </div>
    `
        : `
    <div class="account-summary">
        <h3>Account Summary</h3>
        <div class="summary-grid">
            <div class="summary-item">
                <div class="summary-label">Total Accounts</div>
                <div class="summary-value">${accounts.length}</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Total Balance</div>
                <div class="summary-value">${formatCurrency(accounts.reduce((sum, acc) => sum + Number(acc.balance), 0))}</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Total Transactions</div>
                <div class="summary-value">${transactions.length}</div>
            </div>
        </div>
    </div>
    `
    }

    <h3>Transaction History</h3>
    <table class="transactions-table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Description</th>
                <th>Type</th>
                <th>Reference</th>
                <th>Amount</th>
                <th>Balance</th>
            </tr>
        </thead>
        <tbody>
            ${transactions
              .map(
                (transaction) => `
                <tr>
                    <td>${formatDate(transaction.created_at)}</td>
                    <td>${transaction.description}</td>
                    <td>${transaction.transaction_type.replace("_", " ").toUpperCase()}</td>
                    <td>${transaction.reference_number}</td>
                    <td class="${
                      transaction.transaction_type === "deposit" || transaction.transaction_type === "transfer_in"
                        ? "amount-positive"
                        : "amount-negative"
                    }">
                        ${getAmountPrefix(transaction.transaction_type)}${formatCurrency(Number(transaction.amount))}
                    </td>
                    <td>${formatCurrency(Number(transaction.balance_after))}</td>
                </tr>
            `,
              )
              .join("")}
        </tbody>
    </table>

    <div class="footer">
        <p>This statement was generated on ${new Date().toLocaleDateString("en-US", {
          year: "numeric",
          month: "long",
          day: "numeric",
          hour: "2-digit",
          minute: "2-digit",
        })}</p>
        <p>SecureBank - Your trusted online banking partner</p>
        <p>🔒 This document contains confidential information. Please keep it secure.</p>
    </div>
</body>
</html>
  `
}
