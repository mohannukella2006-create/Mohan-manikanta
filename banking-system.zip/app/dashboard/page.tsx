import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { AccountOverview } from "@/components/dashboard/account-overview"
import { QuickActions } from "@/components/dashboard/quick-actions"
import { RecentTransactions } from "@/components/dashboard/recent-transactions"

export default async function DashboardPage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Get user profile and account data
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", data.user.id).single()

  const { data: accounts } = await supabase.from("accounts").select("*").eq("user_id", data.user.id)

  const { data: recentTransactions } = await supabase
    .from("transactions")
    .select("*")
    .in("account_id", accounts?.map((acc) => acc.id) || [])
    .order("created_at", { ascending: false })
    .limit(5)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <DashboardHeader user={data.user} profile={profile} />

      <main className="container mx-auto px-6 py-8">
        <div className="grid gap-8">
          {/* Account Overview */}
          <AccountOverview accounts={accounts || []} />

          {/* Quick Actions */}
          <QuickActions />

          {/* Recent Transactions */}
          <RecentTransactions transactions={recentTransactions || []} />
        </div>
      </main>
    </div>
  )
}
