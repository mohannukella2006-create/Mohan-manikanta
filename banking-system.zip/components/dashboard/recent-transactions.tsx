import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowDownLeft, ArrowUpRight, ArrowLeftRight, MoreHorizontal } from "lucide-react"
import Link from "next/link"

interface Transaction {
  id: string
  transaction_type: string
  amount: number
  balance_after: number
  description: string
  reference_number: string
  recipient_account_number?: string
  created_at: string
}

interface RecentTransactionsProps {
  transactions: Transaction[]
}

export function RecentTransactions({ transactions }: RecentTransactionsProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "deposit":
        return <ArrowDownLeft className="h-4 w-4 text-green-600" />
      case "withdraw":
        return <ArrowUpRight className="h-4 w-4 text-red-600" />
      case "transfer_out":
        return <ArrowLeftRight className="h-4 w-4 text-blue-600" />
      case "transfer_in":
        return <ArrowDownLeft className="h-4 w-4 text-green-600" />
      default:
        return <MoreHorizontal className="h-4 w-4 text-slate-600" />
    }
  }

  const getTransactionColor = (type: string) => {
    switch (type) {
      case "deposit":
      case "transfer_in":
        return "text-green-600"
      case "withdraw":
      case "transfer_out":
        return "text-red-600"
      default:
        return "text-slate-600"
    }
  }

  const getAmountPrefix = (type: string) => {
    switch (type) {
      case "deposit":
      case "transfer_in":
        return "+"
      case "withdraw":
      case "transfer_out":
        return "-"
      default:
        return ""
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-xl text-slate-900">Recent Transactions</CardTitle>
        <Link href="/dashboard/statement">
          <Button variant="outline" size="sm">
            View All
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        {transactions.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-slate-600">No transactions yet</p>
            <p className="text-sm text-slate-500 mt-1">Your transaction history will appear here</p>
          </div>
        ) : (
          <div className="space-y-4">
            {transactions.map((transaction) => (
              <div
                key={transaction.id}
                className="flex items-center justify-between p-3 rounded-lg border border-slate-100 hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-full bg-slate-100">
                    {getTransactionIcon(transaction.transaction_type)}
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 capitalize">
                      {transaction.transaction_type.replace("_", " ")}
                    </p>
                    <p className="text-sm text-slate-600">
                      {transaction.description || `Ref: ${transaction.reference_number}`}
                    </p>
                    <p className="text-xs text-slate-500">{formatDate(transaction.created_at)}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-semibold ${getTransactionColor(transaction.transaction_type)}`}>
                    {getAmountPrefix(transaction.transaction_type)}
                    {formatCurrency(Number(transaction.amount))}
                  </p>
                  <p className="text-xs text-slate-500">Balance: {formatCurrency(Number(transaction.balance_after))}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
