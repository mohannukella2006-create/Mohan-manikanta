import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowDownLeft, ArrowUpRight, ArrowLeftRight, FileText, CreditCard } from "lucide-react"
import Link from "next/link"

export function QuickActions() {
  const actions = [
    {
      title: "Deposit Cash",
      description: "Add money to your account",
      icon: ArrowDownLeft,
      href: "/dashboard/deposit",
      color: "text-green-600",
      bgColor: "bg-green-50 hover:bg-green-100",
    },
    {
      title: "Withdraw Cash",
      description: "Take money from your account",
      icon: ArrowUpRight,
      href: "/dashboard/withdraw",
      color: "text-red-600",
      bgColor: "bg-red-50 hover:bg-red-100",
    },
    {
      title: "Transfer Money",
      description: "Send money to another account",
      icon: ArrowLeftRight,
      href: "/dashboard/transfer",
      color: "text-blue-600",
      bgColor: "bg-blue-50 hover:bg-blue-100",
    },
    {
      title: "Balance Enquiry",
      description: "Check your current balance",
      icon: CreditCard,
      href: "/dashboard/balance",
      color: "text-purple-600",
      bgColor: "bg-purple-50 hover:bg-purple-100",
    },
    {
      title: "Mini Statement",
      description: "Download transaction history",
      icon: FileText,
      href: "/dashboard/statement",
      color: "text-orange-600",
      bgColor: "bg-orange-50 hover:bg-orange-100",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl text-slate-900">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {actions.map((action) => (
            <Link key={action.title} href={action.href}>
              <Button
                variant="ghost"
                className={`h-auto p-4 flex flex-col items-center gap-3 w-full ${action.bgColor} border border-slate-200 hover:border-slate-300 transition-all`}
              >
                <div className={`p-3 rounded-full bg-white shadow-sm`}>
                  <action.icon className={`h-6 w-6 ${action.color}`} />
                </div>
                <div className="text-center">
                  <p className="font-medium text-slate-900 text-sm">{action.title}</p>
                  <p className="text-xs text-slate-600 mt-1">{action.description}</p>
                </div>
              </Button>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
