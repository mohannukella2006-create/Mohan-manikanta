"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CreditCard, ArrowLeft, Eye, EyeOff, Wallet } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

interface Account {
  id: string
  account_number: string
  account_type: string
  balance: number
  created_at: string
}

interface BalanceEnquiryProps {
  accounts: Account[]
}

export function BalanceEnquiry({ accounts }: BalanceEnquiryProps) {
  const [showBalance, setShowBalance] = useState(true)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount)
  }

  const formatAccountNumber = (accountNumber: string) => {
    return `${accountNumber.slice(0, 4)} ${accountNumber.slice(4, 8)} ${accountNumber.slice(8)}`
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const totalBalance = accounts.reduce((sum, account) => sum + Number(account.balance), 0)

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <Link href="/dashboard">
          <Button variant="ghost" className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>
      </div>

      <div className="space-y-6">
        {/* Header */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-purple-100 p-2 rounded-lg">
                  <CreditCard className="h-6 w-6 text-purple-600" />
                </div>
                <div>
                  <CardTitle className="text-xl">Balance Enquiry</CardTitle>
                  <CardDescription>View your current account balances</CardDescription>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowBalance(!showBalance)}
                className="flex items-center gap-2"
              >
                {showBalance ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                {showBalance ? "Hide" : "Show"}
              </Button>
            </div>
          </CardHeader>
        </Card>

        {/* Total Balance Summary */}
        <Card className="bg-gradient-to-r from-purple-600 to-purple-700 text-white border-0">
          <CardHeader>
            <CardTitle className="text-lg font-medium">Total Balance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{showBalance ? formatCurrency(totalBalance) : "••••••"}</div>
            <p className="text-purple-100 text-sm mt-1">
              Across {accounts.length} account{accounts.length !== 1 ? "s" : ""}
            </p>
          </CardContent>
        </Card>

        {/* Individual Account Details */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-900">Account Details</h3>
          {accounts.map((account) => (
            <Card key={account.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-slate-100 p-2 rounded-lg">
                      <Wallet className="h-5 w-5 text-slate-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-900 capitalize">{account.account_type} Account</h4>
                      <p className="text-sm text-slate-600">
                        Account Number: {formatAccountNumber(account.account_number)}
                      </p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    Active
                  </Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Available Balance</p>
                    <p className="text-2xl font-bold text-slate-900">
                      {showBalance ? formatCurrency(Number(account.balance)) : "••••••"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Account Type</p>
                    <p className="font-medium text-slate-900 capitalize">{account.account_type}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Account Opened</p>
                    <p className="font-medium text-slate-900">{formatDate(account.created_at)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Link href="/dashboard/deposit">
                <Button variant="outline" className="w-full bg-transparent">
                  Deposit
                </Button>
              </Link>
              <Link href="/dashboard/withdraw">
                <Button variant="outline" className="w-full bg-transparent">
                  Withdraw
                </Button>
              </Link>
              <Link href="/dashboard/transfer">
                <Button variant="outline" className="w-full bg-transparent">
                  Transfer
                </Button>
              </Link>
              <Link href="/dashboard/statement">
                <Button variant="outline" className="w-full bg-transparent">
                  Statement
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
