"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeftRight, ArrowLeft, CheckCircle } from "lucide-react"
import Link from "next/link"

interface Account {
  id: string
  account_number: string
  account_type: string
  balance: number
}

interface TransferFormProps {
  accounts: Account[]
}

export function TransferForm({ accounts }: TransferFormProps) {
  const [selectedAccount, setSelectedAccount] = useState("")
  const [recipientAccount, setRecipientAccount] = useState("")
  const [amount, setAmount] = useState("")
  const [description, setDescription] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount)
  }

  const selectedAccountData = accounts.find((acc) => acc.id === selectedAccount)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    if (!selectedAccount || !recipientAccount || !amount) {
      setError("Please fill in all required fields")
      setIsLoading(false)
      return
    }

    const transferAmount = Number.parseFloat(amount)
    if (transferAmount <= 0) {
      setError("Amount must be greater than zero")
      setIsLoading(false)
      return
    }

    if (selectedAccountData && transferAmount > Number(selectedAccountData.balance)) {
      setError("Insufficient funds")
      setIsLoading(false)
      return
    }

    // Basic account number validation (12 digits starting with 4000)
    if (!/^4000\d{8}$/.test(recipientAccount)) {
      setError("Invalid account number format")
      setIsLoading(false)
      return
    }

    try {
      const response = await fetch("/api/transactions/transfer", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          fromAccountId: selectedAccount,
          toAccountNumber: recipientAccount,
          amount: transferAmount,
          description: description || "Money transfer",
        }),
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || "Transfer failed")
      }

      setSuccess(true)
      setTimeout(() => {
        router.push("/dashboard")
      }, 2000)
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  if (success) {
    return (
      <div className="max-w-md mx-auto">
        <Card className="text-center">
          <CardHeader>
            <div className="mx-auto bg-green-100 p-3 rounded-full w-fit mb-4">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <CardTitle className="text-green-600">Transfer Successful!</CardTitle>
            <CardDescription>Your money transfer has been processed successfully</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-slate-600 mb-4">Redirecting to dashboard...</p>
            <Link href="/dashboard">
              <Button className="w-full">Return to Dashboard</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="max-w-md mx-auto">
      <div className="mb-6">
        <Link href="/dashboard">
          <Button variant="ghost" className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-blue-100 p-2 rounded-lg">
              <ArrowLeftRight className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <CardTitle className="text-xl">Money Transfer</CardTitle>
              <CardDescription>Send money to another account</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="account">From Account</Label>
              <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose account to transfer from" />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      <div className="flex justify-between items-center w-full">
                        <span className="capitalize">{account.account_type} Account</span>
                        <span className="text-sm text-slate-500 ml-2">
                          ****{account.account_number.slice(-4)} - {formatCurrency(Number(account.balance))}
                        </span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedAccountData && (
                <p className="text-sm text-slate-600">
                  Available balance: {formatCurrency(Number(selectedAccountData.balance))}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="recipient">To Account Number</Label>
              <Input
                id="recipient"
                type="text"
                placeholder="400012345678"
                value={recipientAccount}
                onChange={(e) => setRecipientAccount(e.target.value)}
                maxLength={12}
                className="font-mono"
              />
              <p className="text-xs text-slate-500">Enter the 12-digit account number</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0.01"
                max={selectedAccountData ? Number(selectedAccountData.balance) : undefined}
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="text-lg"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description (Optional)</Label>
              <Input
                id="description"
                type="text"
                placeholder="e.g., Payment for services"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                <p className="text-sm text-red-600">{error}</p>
              </div>
            )}

            <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={isLoading}>
              {isLoading ? "Processing..." : "Transfer Money"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
