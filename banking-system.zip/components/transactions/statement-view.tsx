"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  FileText,
  ArrowLeft,
  Download,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  MoreHorizontal,
  Calendar,
  Filter,
} from "lucide-react"
import Link from "next/link"

interface Account {
  id: string
  account_number: string
  account_type: string
  balance: number
}

interface Transaction {
  id: string
  account_id: string
  transaction_type: string
  amount: number
  balance_after: number
  description: string
  reference_number: string
  recipient_account_number?: string
  created_at: string
}

interface Profile {
  full_name: string
  phone_number?: string
  address?: string
}

interface StatementViewProps {
  accounts: Account[]
  transactions: Transaction[]
  profile: Profile
}

export function StatementView({ accounts, transactions, profile }: StatementViewProps) {
  const [selectedAccount, setSelectedAccount] = useState("all")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [transactionType, setTransactionType] = useState("all")
  const [isDownloading, setIsDownloading] = useState(false)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const formatAccountNumber = (accountNumber: string) => {
    return `${accountNumber.slice(0, 4)} ${accountNumber.slice(4, 8)} ${accountNumber.slice(8)}`
  }

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "deposit":
        return <ArrowDownLeft className="h-4 w-4 text-green-600" />
      case "withdraw":
        return <ArrowUpRight className="h-4 w-4 text-red-600" />
      case "transfer_out":
        return <ArrowLeftRight className="h-4 w-4 text-blue-600" />
      case "transfer_in":
        return <ArrowDownLeft className="h-4 w-4 text-green-600" />
      default:
        return <MoreHorizontal className="h-4 w-4 text-slate-600" />
    }
  }

  const getTransactionColor = (type: string) => {
    switch (type) {
      case "deposit":
      case "transfer_in":
        return "text-green-600"
      case "withdraw":
      case "transfer_out":
        return "text-red-600"
      default:
        return "text-slate-600"
    }
  }

  const getAmountPrefix = (type: string) => {
    switch (type) {
      case "deposit":
      case "transfer_in":
        return "+"
      case "withdraw":
      case "transfer_out":
        return "-"
      default:
        return ""
    }
  }

  // Filter transactions based on selected criteria
  const filteredTransactions = transactions.filter((transaction) => {
    const transactionDate = new Date(transaction.created_at)
    const fromDate = dateFrom ? new Date(dateFrom) : null
    const toDate = dateTo ? new Date(dateTo) : null

    // Account filter
    if (selectedAccount !== "all" && transaction.account_id !== selectedAccount) {
      return false
    }

    // Date range filter
    if (fromDate && transactionDate < fromDate) {
      return false
    }
    if (toDate && transactionDate > toDate) {
      return false
    }

    // Transaction type filter
    if (transactionType !== "all" && transaction.transaction_type !== transactionType) {
      return false
    }

    return true
  })

  const handleDownloadStatement = async () => {
    setIsDownloading(true)
    try {
      const response = await fetch("/api/statements/download", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          accountId: selectedAccount,
          dateFrom,
          dateTo,
          transactionType,
        }),
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.style.display = "none"
        a.href = url
        a.download = `statement-${new Date().toISOString().split("T")[0]}.pdf`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      } else {
        console.error("Failed to download statement")
      }
    } catch (error) {
      console.error("Error downloading statement:", error)
    } finally {
      setIsDownloading(false)
    }
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-6">
        <Link href="/dashboard">
          <Button variant="ghost" className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>
      </div>

      <div className="space-y-6">
        {/* Header */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-orange-100 p-2 rounded-lg">
                  <FileText className="h-6 w-6 text-orange-600" />
                </div>
                <div>
                  <CardTitle className="text-xl">Account Statement</CardTitle>
                  <CardDescription>View and download your transaction history</CardDescription>
                </div>
              </div>
              <Button
                onClick={handleDownloadStatement}
                disabled={isDownloading}
                className="bg-orange-600 hover:bg-orange-700"
              >
                <Download className="h-4 w-4 mr-2" />
                {isDownloading ? "Generating..." : "Download PDF"}
              </Button>
            </div>
          </CardHeader>
        </Card>

        {/* Filters */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Filter className="h-5 w-5 text-slate-600" />
              <CardTitle className="text-lg">Filter Transactions</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="account">Account</Label>
                <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                  <SelectTrigger>
                    <SelectValue placeholder="All accounts" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Accounts</SelectItem>
                    {accounts.map((account) => (
                      <SelectItem key={account.id} value={account.id}>
                        <span className="capitalize">{account.account_type}</span> - ****
                        {account.account_number.slice(-4)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="dateFrom">From Date</Label>
                <Input id="dateFrom" type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="dateTo">To Date</Label>
                <Input id="dateTo" type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="transactionType">Transaction Type</Label>
                <Select value={transactionType} onValueChange={setTransactionType}>
                  <SelectTrigger>
                    <SelectValue placeholder="All types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="deposit">Deposits</SelectItem>
                    <SelectItem value="withdraw">Withdrawals</SelectItem>
                    <SelectItem value="transfer_in">Transfers In</SelectItem>
                    <SelectItem value="transfer_out">Transfers Out</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Account Summary */}
        {selectedAccount !== "all" && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Account Summary</CardTitle>
            </CardHeader>
            <CardContent>
              {(() => {
                const account = accounts.find((acc) => acc.id === selectedAccount)
                if (!account) return null
                return (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-slate-600 mb-1">Account Number</p>
                      <p className="font-mono text-sm">{formatAccountNumber(account.account_number)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-slate-600 mb-1">Account Type</p>
                      <p className="font-medium capitalize">{account.account_type}</p>
                    </div>
                    <div>
                      <p className="text-sm text-slate-600 mb-1">Current Balance</p>
                      <p className="text-xl font-bold text-slate-900">{formatCurrency(Number(account.balance))}</p>
                    </div>
                  </div>
                )
              })()}
            </CardContent>
          </Card>
        )}

        {/* Transaction History */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg">Transaction History</CardTitle>
              <CardDescription>
                Showing {filteredTransactions.length} transaction{filteredTransactions.length !== 1 ? "s" : ""}
              </CardDescription>
            </div>
            <Badge variant="secondary" className="text-xs">
              {filteredTransactions.length} Records
            </Badge>
          </CardHeader>
          <CardContent>
            {filteredTransactions.length === 0 ? (
              <div className="text-center py-12">
                <Calendar className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-600 mb-2">No transactions found</p>
                <p className="text-sm text-slate-500">Try adjusting your filter criteria</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredTransactions.map((transaction) => {
                  const account = accounts.find((acc) => acc.id === transaction.account_id)
                  return (
                    <div
                      key={transaction.id}
                      className="flex items-center justify-between p-4 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div className="p-2 rounded-full bg-slate-100">
                          {getTransactionIcon(transaction.transaction_type)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-medium text-slate-900 capitalize">
                              {transaction.transaction_type.replace("_", " ")}
                            </p>
                            {account && (
                              <Badge variant="outline" className="text-xs">
                                {account.account_type} ****{account.account_number.slice(-4)}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-slate-600">{transaction.description}</p>
                          <div className="flex items-center gap-4 mt-1">
                            <p className="text-xs text-slate-500">Ref: {transaction.reference_number}</p>
                            <p className="text-xs text-slate-500">{formatDate(transaction.created_at)}</p>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`font-semibold text-lg ${getTransactionColor(transaction.transaction_type)}`}>
                          {getAmountPrefix(transaction.transaction_type)}
                          {formatCurrency(Number(transaction.amount))}
                        </p>
                        <p className="text-xs text-slate-500">
                          Balance: {formatCurrency(Number(transaction.balance_after))}
                        </p>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
